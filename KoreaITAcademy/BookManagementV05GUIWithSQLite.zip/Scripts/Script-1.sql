SELECT	*
FROM	BookRentalHistoryInfo