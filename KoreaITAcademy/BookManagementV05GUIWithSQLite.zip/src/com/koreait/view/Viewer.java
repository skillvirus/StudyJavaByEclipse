package com.koreait.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Viewer {

	private JFrame frmMain;
	private JMenuBar mnubMain;
	private JMenu mnuFile;
	private JMenuItem mnuiHome;
	private JMenuItem mnuiEnd;
	private JMenu mnuUserInfoMng;
	private JMenuItem mnuiUserInfoInsert;
	private JMenuItem mnuiUserInfoDelete;
	private JMenuItem mnuiUserInfoUpdate;
	private JMenuItem mnuiUserInfoSelect;
	private JMenu mnuBookInfoMng;
	private JMenuItem mnuiBookInfoInsert;
	private JMenuItem mnuiBookInfoDelete;
	private JMenuItem mnuiBookInfoUpdate;
	private JMenuItem mnuiBookInfoSelect;
	private JMenu mnuBookRentalMng;
	private JMenuItem mnuiBookRentalInsert;
	private JMenuItem mnuiBookReturnInsert;
	private JMenuItem mnuiBookRentalHistorySelect;
	private JMenu mnuHelp;
	private JPanel pnlMain;
	private JPanel pnlUserInfoInsert;
	private JPanel pnlUserInfoDelete;
	private JPanel pnlUserInfoUpdate;
	private JPanel pnlUserInfoSelect;
	private JPanel pnlBookInfoInsert;
	private JPanel pnlBookInfoDelete;
	private JPanel pnlBookInfoUpdate;
	private JPanel pnlBookInfoSelect;
	private JPanel pnlBookRentalInsert;
	private JPanel pnlBookReturnInsert;
	private JPanel pnlBookRentalHistorySelect;
	private JLabel lblResultInfo;
	private JLabel lblMainTtile;
	private JLabel lblUserInfoInsertPnlTitle;
	private JLabel lblUserInfoDeletePnlTitle;
	private JLabel lblUserInfoUpdatePnlTitle;
	private JLabel lblUserInfoSelectPnlTitle;
	private JLabel lblBookInfoInsertPnlTitle;
	private JLabel lblBookInfoDeletePnlTitle;
	private JLabel lblBookInfoUpdatePnlTitle;
	private JLabel lblBookInfoSelectPnlTitle;
	private JLabel lblBookRentalInsertPnlTitle;
	private JLabel lblBookReturnInsertPnlTitle;
	private JLabel lblBookRentalHistorySelectPnlTitle;
	private JTextField txfUserInfoInsertID;
	private JTextField txfUserInfoInsertName;
	private JTextField txfUserInfoInsertPhoneNum;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Viewer window = new Viewer();
					window.frmMain.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Viewer() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMain = new JFrame();
		frmMain.addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				setPanelVisible("pnlMain");
			}
		});
		frmMain.setBounds(100, 100, 650, 420);
		frmMain.setLocationRelativeTo(null);
		frmMain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMain.getContentPane().setLayout(null);
		
		pnlUserInfoInsert = new JPanel();
		pnlUserInfoInsert.setBounds(0, 20, 634, 339);
		frmMain.getContentPane().add(pnlUserInfoInsert);
		pnlUserInfoInsert.setLayout(null);
		
		lblUserInfoInsertPnlTitle = new JLabel("[사용자 정보 등록]");
		lblUserInfoInsertPnlTitle.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoInsertPnlTitle.setBounds(0, 0, 150, 15);
		pnlUserInfoInsert.add(lblUserInfoInsertPnlTitle);
		
		JLabel lblUserInfoInsertID = new JLabel("ID");
		lblUserInfoInsertID.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoInsertID.setBounds(12, 39, 57, 15);
		pnlUserInfoInsert.add(lblUserInfoInsertID);
		
		txfUserInfoInsertID = new JTextField();
		txfUserInfoInsertID.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfUserInfoInsertID.setBounds(81, 36, 116, 21);
		pnlUserInfoInsert.add(txfUserInfoInsertID);
		txfUserInfoInsertID.setColumns(10);
		
		JLabel lblUserInfoInsertName = new JLabel("이름");
		lblUserInfoInsertName.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoInsertName.setBounds(12, 67, 57, 15);
		pnlUserInfoInsert.add(lblUserInfoInsertName);
		
		txfUserInfoInsertName = new JTextField();
		txfUserInfoInsertName.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfUserInfoInsertName.setColumns(10);
		txfUserInfoInsertName.setBounds(81, 64, 116, 21);
		pnlUserInfoInsert.add(txfUserInfoInsertName);
		
		JLabel lblUserInfoInsertPhoneNum = new JLabel("전화번호");
		lblUserInfoInsertPhoneNum.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoInsertPhoneNum.setBounds(12, 95, 57, 15);
		pnlUserInfoInsert.add(lblUserInfoInsertPhoneNum);
		
		txfUserInfoInsertPhoneNum = new JTextField();
		txfUserInfoInsertPhoneNum.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfUserInfoInsertPhoneNum.setColumns(10);
		txfUserInfoInsertPhoneNum.setBounds(81, 92, 116, 21);
		pnlUserInfoInsert.add(txfUserInfoInsertPhoneNum);
		
		JButton btnUserInfoInsert = new JButton("등록");
		btnUserInfoInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//DB접속
				//쿼리 생성
				//쿼리 실행
				Connection con = null;
				PreparedStatement prst = null;
				String query;
				
				try {
					query = " INSERT INTO UserInfo (UserID, UserName, UserPhoneNum) VALUES (?, ?, ?)";
					
					Class.forName("org.sqlite.JDBC");
					
					con = DriverManager.getConnection("jdbc:sqlite:./././Resources/Database/BookManagement.db");
					prst = con.prepareStatement(query);
					
					prst.setString(1, txfUserInfoInsertID.getText()); //ID
					prst.setString(2, txfUserInfoInsertName.getText()); //이름
					prst.setString(3, txfUserInfoInsertPhoneNum.getText()); //전화번호
					
					prst.executeUpdate();
					
					con.close();
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
			}
		});
		btnUserInfoInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnUserInfoInsert.setBounds(12, 306, 97, 23);
		pnlUserInfoInsert.add(btnUserInfoInsert);
		
		mnubMain = new JMenuBar();
		mnubMain.setBounds(0, 0, 634, 23);
		frmMain.getContentPane().add(mnubMain);
		
		mnuFile = new JMenu("파일");
		mnuFile.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuFile);
		
		mnuiHome = new JMenuItem("홈");
		mnuiHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlMain");
			}
		});
		mnuiHome.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuFile.add(mnuiHome);
		
		mnuiEnd = new JMenuItem("종료");
		mnuiEnd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnuiEnd.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuFile.add(mnuiEnd);
		
		mnuUserInfoMng = new JMenu("사용자 정보 관리");
		mnuUserInfoMng.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuUserInfoMng);
		
		mnuiUserInfoInsert = new JMenuItem("사용자 정보 등록");
		mnuiUserInfoInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlUserInfoInsert");
			}
		});
		mnuiUserInfoInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuUserInfoMng.add(mnuiUserInfoInsert);
		
		mnuiUserInfoDelete = new JMenuItem("사용자 정보 삭제");
		mnuiUserInfoDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlUserInfoDelete");
			}
		});
		mnuiUserInfoDelete.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuUserInfoMng.add(mnuiUserInfoDelete);
		
		mnuiUserInfoUpdate = new JMenuItem("사용자 정보 수정");
		mnuiUserInfoUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlUserInfoUpdate");
			}
		});
		mnuiUserInfoUpdate.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuUserInfoMng.add(mnuiUserInfoUpdate);
		
		mnuiUserInfoSelect = new JMenuItem("사용자 정보 조회");
		mnuiUserInfoSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlUserInfoSelect");
			}
		});
		mnuiUserInfoSelect.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuUserInfoMng.add(mnuiUserInfoSelect);
		
		mnuBookInfoMng = new JMenu("도서 정보 관리");
		mnuBookInfoMng.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuBookInfoMng);
		
		mnuiBookInfoInsert = new JMenuItem("도서 정보 등록");
		mnuiBookInfoInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookInfoInsert");
			}
		});
		mnuiBookInfoInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookInfoMng.add(mnuiBookInfoInsert);
		
		mnuiBookInfoDelete = new JMenuItem("도서 정보 삭제");
		mnuiBookInfoDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookInfoDelete");
			}
		});
		mnuiBookInfoDelete.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookInfoMng.add(mnuiBookInfoDelete);
		
		mnuiBookInfoUpdate = new JMenuItem("도서 정보 수정");
		mnuiBookInfoUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookInfoUpdate");
			}
		});
		mnuiBookInfoUpdate.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookInfoMng.add(mnuiBookInfoUpdate);
		
		mnuiBookInfoSelect = new JMenuItem("도서 정보 조회");
		mnuiBookInfoSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookInfoSelect");
			}
		});
		mnuiBookInfoSelect.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookInfoMng.add(mnuiBookInfoSelect);
		
		mnuBookRentalMng = new JMenu("도서 대여 관리");
		mnuBookRentalMng.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuBookRentalMng);
		
		mnuiBookRentalInsert = new JMenuItem("도서 대출 등록");
		mnuiBookRentalInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookRentalInsert");
			}
		});
		mnuiBookRentalInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookRentalMng.add(mnuiBookRentalInsert);
		
		mnuiBookReturnInsert = new JMenuItem("도서 반납 등록");
		mnuiBookReturnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookReturnInsert");
			}
		});
		mnuiBookReturnInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookRentalMng.add(mnuiBookReturnInsert);
		
		mnuiBookRentalHistorySelect = new JMenuItem("도서 대여 이력 조회");
		mnuiBookRentalHistorySelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookRentalHistorySelect");
			}
		});
		mnuiBookRentalHistorySelect.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookRentalMng.add(mnuiBookRentalHistorySelect);
		
		mnuHelp = new JMenu("도움말");
		mnuHelp.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuHelp);
		
		pnlMain = new JPanel();
		pnlMain.setBounds(0, 20, 634, 339);
		frmMain.getContentPane().add(pnlMain);
		pnlMain.setLayout(null);
		
		lblMainTtile = new JLabel("도서 대여 관리 프로그램");
		lblMainTtile.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		lblMainTtile.setHorizontalAlignment(SwingConstants.CENTER);
		lblMainTtile.setBounds(0, 143, 634, 46);
		pnlMain.add(lblMainTtile);
		
		pnlUserInfoDelete = new JPanel();
		pnlUserInfoDelete.setBounds(0, 20, 634, 339);
		frmMain.getContentPane().add(pnlUserInfoDelete);
		pnlUserInfoDelete.setLayout(null);
		
		lblUserInfoDeletePnlTitle = new JLabel("[사용자 정보 삭제]");
		lblUserInfoDeletePnlTitle.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoDeletePnlTitle.setBounds(0, 0, 150, 15);
		pnlUserInfoDelete.add(lblUserInfoDeletePnlTitle);
		
		pnlUserInfoUpdate = new JPanel();
		pnlUserInfoUpdate.setBounds(0, 20, 634, 339);
		frmMain.getContentPane().add(pnlUserInfoUpdate);
		pnlUserInfoUpdate.setLayout(null);
		
		lblUserInfoUpdatePnlTitle = new JLabel("[사용자 정보 수정]");
		lblUserInfoUpdatePnlTitle.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoUpdatePnlTitle.setBounds(0, 0, 150, 15);
		pnlUserInfoUpdate.add(lblUserInfoUpdatePnlTitle);
		
		pnlUserInfoSelect = new JPanel();
		pnlUserInfoSelect.setBounds(0, 20, 634, 339);
		frmMain.getContentPane().add(pnlUserInfoSelect);
		pnlUserInfoSelect.setLayout(null);
		
		lblUserInfoSelectPnlTitle = new JLabel("[사용자 정보 조회]");
		lblUserInfoSelectPnlTitle.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoSelectPnlTitle.setBounds(0, 0, 150, 15);
		pnlUserInfoSelect.add(lblUserInfoSelectPnlTitle);
		
		pnlBookInfoInsert = new JPanel();
		pnlBookInfoInsert.setBounds(0, 20, 634, 339);
		frmMain.getContentPane().add(pnlBookInfoInsert);
		pnlBookInfoInsert.setLayout(null);
		
		lblBookInfoInsertPnlTitle = new JLabel("[도서 정보 등록]");
		lblBookInfoInsertPnlTitle.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblBookInfoInsertPnlTitle.setBounds(0, 0, 150, 15);
		pnlBookInfoInsert.add(lblBookInfoInsertPnlTitle);
		
		pnlBookInfoDelete = new JPanel();
		pnlBookInfoDelete.setBounds(0, 20, 634, 339);
		frmMain.getContentPane().add(pnlBookInfoDelete);
		pnlBookInfoDelete.setLayout(null);
		
		lblBookInfoDeletePnlTitle = new JLabel("[도서 정보 삭제]");
		lblBookInfoDeletePnlTitle.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblBookInfoDeletePnlTitle.setBounds(0, 0, 150, 15);
		pnlBookInfoDelete.add(lblBookInfoDeletePnlTitle);
		
		pnlBookInfoUpdate = new JPanel();
		pnlBookInfoUpdate.setBounds(0, 20, 634, 339);
		frmMain.getContentPane().add(pnlBookInfoUpdate);
		pnlBookInfoUpdate.setLayout(null);
		
		lblBookInfoUpdatePnlTitle = new JLabel("[도서 정보 수정]");
		lblBookInfoUpdatePnlTitle.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblBookInfoUpdatePnlTitle.setBounds(0, 0, 150, 15);
		pnlBookInfoUpdate.add(lblBookInfoUpdatePnlTitle);
		
		pnlBookInfoSelect = new JPanel();
		pnlBookInfoSelect.setBounds(0, 20, 634, 339);
		frmMain.getContentPane().add(pnlBookInfoSelect);
		pnlBookInfoSelect.setLayout(null);
		
		lblBookInfoSelectPnlTitle = new JLabel("[도서 정보 조회]");
		lblBookInfoSelectPnlTitle.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblBookInfoSelectPnlTitle.setBounds(0, 0, 150, 15);
		pnlBookInfoSelect.add(lblBookInfoSelectPnlTitle);
		
		pnlBookRentalInsert = new JPanel();
		pnlBookRentalInsert.setBounds(0, 20, 634, 339);
		frmMain.getContentPane().add(pnlBookRentalInsert);
		pnlBookRentalInsert.setLayout(null);
		
		lblBookRentalInsertPnlTitle = new JLabel("[도서 대출 등록]");
		lblBookRentalInsertPnlTitle.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblBookRentalInsertPnlTitle.setBounds(0, 0, 150, 15);
		pnlBookRentalInsert.add(lblBookRentalInsertPnlTitle);
		
		pnlBookReturnInsert = new JPanel();
		pnlBookReturnInsert.setBounds(0, 20, 634, 339);
		frmMain.getContentPane().add(pnlBookReturnInsert);
		pnlBookReturnInsert.setLayout(null);
		
		lblBookReturnInsertPnlTitle = new JLabel("[도서 반납 등록]");
		lblBookReturnInsertPnlTitle.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblBookReturnInsertPnlTitle.setBounds(0, 0, 150, 15);
		pnlBookReturnInsert.add(lblBookReturnInsertPnlTitle);
		
		pnlBookRentalHistorySelect = new JPanel();
		pnlBookRentalHistorySelect.setBounds(0, 20, 634, 339);
		frmMain.getContentPane().add(pnlBookRentalHistorySelect);
		pnlBookRentalHistorySelect.setLayout(null);
		
		lblBookRentalHistorySelectPnlTitle = new JLabel("[도서 대여 이력 조회]");
		lblBookRentalHistorySelectPnlTitle.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblBookRentalHistorySelectPnlTitle.setBounds(0, 0, 150, 15);
		pnlBookRentalHistorySelect.add(lblBookRentalHistorySelectPnlTitle);
		
		lblResultInfo = new JLabel("");
		lblResultInfo.setBounds(0, 360, 634, 20);
		frmMain.getContentPane().add(lblResultInfo);
	}
	
	/*
	 * 리플렉션(객체를 통해 클래스의 정보를 알아냄)을 이용하여 Panel Visible 설정 
	 */
	private void setPanelVisible(String panelName) {
		try {
			Class<?> c = Class.forName("com.koreait.view.Viewer");
			Field[] allField = c.getDeclaredFields();
			
			for (Field field : allField){
				if (field.getType().getName().equals("javax.swing.JPanel")) { //panel 일 때
					//field.setAccessible(true); //private 멤버에 접근 가능하게 설정
					
					JPanel p = (JPanel)field.get(this); //JPanel로 형변환
					
					if (field.getName().equals(panelName)) {
						p.setVisible(true);
					} else {
						p.setVisible(false);
					}
				}
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
