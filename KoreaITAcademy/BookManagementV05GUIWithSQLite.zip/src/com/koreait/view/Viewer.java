package com.koreait.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Viewer {

	private JFrame frmMain;
	private JMenuBar mnubMain;
	private JMenu mnuFile;
	private JMenuItem mnuiHome;
	private JMenuItem mnuiEnd;
	private JMenu mnuUserInfoMng;
	private JMenuItem mnuiUserInfoInsert;
	private JMenuItem mnuiUserInfoDelete;
	private JMenuItem mnuiUserInfoUpdate;
	private JMenuItem mnuiUserInfoSelect;
	private JMenu mnuBookInfoMng;
	private JMenuItem mnuiBookInfoInsert;
	private JMenuItem mnuiBookInfoDelete;
	private JMenuItem mnuiBookInfoUpdate;
	private JMenuItem mnuiBookInfoSelect;
	private JMenu mnuBookRentalMng;
	private JMenuItem mnuiBookRentalInsert;
	private JMenuItem mnuiBookReturnInsert;
	private JMenuItem mnuiBookRentalHistorySelect;
	private JMenu mnuHelp;	
	private JLabel lblResultInfo;
	private JPanel pnlMain;	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Viewer window = new Viewer();
					window.frmMain.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Viewer() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMain = new JFrame();
		frmMain.addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				pnlMain.setVisible(true);
				//나머지 패널 setVisible(false);
			}
		});
		frmMain.setBounds(100, 100, 650, 420);
		frmMain.setLocationRelativeTo(null);
		frmMain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMain.getContentPane().setLayout(null);
		
		mnubMain = new JMenuBar();
		mnubMain.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.setBounds(0, 0, 634, 23);
		frmMain.getContentPane().add(mnubMain);
		
		mnuFile = new JMenu("파일");
		mnuFile.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuFile);
		
		mnuiHome = new JMenuItem("홈");
		mnuiHome.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuFile.add(mnuiHome);
		
		mnuiEnd = new JMenuItem("종료");
		mnuiEnd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnuiEnd.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuFile.add(mnuiEnd);
		
		mnuUserInfoMng = new JMenu("사용자 정보 관리");
		mnuUserInfoMng.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuUserInfoMng);
		
		mnuiUserInfoInsert = new JMenuItem("사용자 정보 등록");
		mnuiUserInfoInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuUserInfoMng.add(mnuiUserInfoInsert);
		
		mnuiUserInfoDelete = new JMenuItem("사용자 정보 삭제");
		mnuiUserInfoDelete.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuUserInfoMng.add(mnuiUserInfoDelete);
		
		mnuiUserInfoUpdate = new JMenuItem("사용자 정보 수정");
		mnuiUserInfoUpdate.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuUserInfoMng.add(mnuiUserInfoUpdate);
		
		mnuiUserInfoSelect = new JMenuItem("사용자 정보 조회");
		mnuiUserInfoSelect.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuUserInfoMng.add(mnuiUserInfoSelect);
		
		mnuBookInfoMng = new JMenu("도서 정보 관리");
		mnuBookInfoMng.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuBookInfoMng);
		
		mnuiBookInfoInsert = new JMenuItem("도서 정보 등록");
		mnuiBookInfoInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookInfoMng.add(mnuiBookInfoInsert);
		
		mnuiBookInfoDelete = new JMenuItem("도서 정보 삭제");
		mnuiBookInfoDelete.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookInfoMng.add(mnuiBookInfoDelete);
		
		mnuiBookInfoUpdate = new JMenuItem("도서 정보 수정");
		mnuiBookInfoUpdate.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookInfoMng.add(mnuiBookInfoUpdate);
		
		mnuiBookInfoSelect = new JMenuItem("도서 정보 조회");
		mnuiBookInfoSelect.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookInfoMng.add(mnuiBookInfoSelect);
		
		mnuBookRentalMng = new JMenu("도서 대여 관리");
		mnuBookRentalMng.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuBookRentalMng);
		
		mnuiBookRentalInsert = new JMenuItem("도서 대출 등록");
		mnuiBookRentalInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookRentalMng.add(mnuiBookRentalInsert);
		
		mnuiBookReturnInsert = new JMenuItem("도서 반납 등록");
		mnuiBookReturnInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookRentalMng.add(mnuiBookReturnInsert);
		
		mnuiBookRentalHistorySelect = new JMenuItem("도서 대여 이력 조회");
		mnuiBookRentalHistorySelect.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookRentalMng.add(mnuiBookRentalHistorySelect);
		
		mnuHelp = new JMenu("도움말");
		mnuHelp.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuHelp);
		
		lblResultInfo = new JLabel("");
		lblResultInfo.setBounds(0, 366, 634, 15);
		frmMain.getContentPane().add(lblResultInfo);
		
		pnlMain = new JPanel();
		pnlMain.setBounds(0, 21, 634, 336);
		frmMain.getContentPane().add(pnlMain);
		pnlMain.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("도서 대여 관리 프로그램");
		lblNewLabel.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 143, 634, 48);
		pnlMain.add(lblNewLabel);
		
		JPanel pnlUserInfoInsert = new JPanel();
		pnlUserInfoInsert.setBounds(0, 0, 10, 10);
		frmMain.getContentPane().add(pnlUserInfoInsert);
		
		JPanel pnlUserInfoDelete = new JPanel();
		pnlUserInfoDelete.setBounds(0, 0, 10, 10);
		frmMain.getContentPane().add(pnlUserInfoDelete);
		
		JPanel pnlUserInfoUpdate = new JPanel();
		pnlUserInfoUpdate.setBounds(0, 0, 10, 10);
		frmMain.getContentPane().add(pnlUserInfoUpdate);
		
		JPanel pnlUserInfoSelect = new JPanel();
		pnlUserInfoSelect.setBounds(0, 0, 10, 10);
		frmMain.getContentPane().add(pnlUserInfoSelect);
		
		JPanel pnlBookInfoInsert = new JPanel();
		pnlBookInfoInsert.setBounds(0, 0, 10, 10);
		frmMain.getContentPane().add(pnlBookInfoInsert);
		
		JPanel pnlBookInfoDelete = new JPanel();
		pnlBookInfoDelete.setBounds(0, 0, 10, 10);
		frmMain.getContentPane().add(pnlBookInfoDelete);
		
		JPanel pnlBookInfoUpdate = new JPanel();
		pnlBookInfoUpdate.setBounds(0, 0, 10, 10);
		frmMain.getContentPane().add(pnlBookInfoUpdate);
		
		JPanel pnlBookInfoSelect = new JPanel();
		pnlBookInfoSelect.setBounds(0, 0, 10, 10);
		frmMain.getContentPane().add(pnlBookInfoSelect);
		
		JPanel pnlBookRentalInsert = new JPanel();
		pnlBookRentalInsert.setBounds(0, 0, 10, 10);
		frmMain.getContentPane().add(pnlBookRentalInsert);
		
		JPanel pnlBookReturnInsert = new JPanel();
		pnlBookReturnInsert.setBounds(0, 0, 10, 10);
		frmMain.getContentPane().add(pnlBookReturnInsert);
		
		JPanel pnlBookRentalHistorySelect = new JPanel();
		pnlBookRentalHistorySelect.setBounds(0, 0, 10, 10);
		frmMain.getContentPane().add(pnlBookRentalHistorySelect);
	}
}
