package com.koreait.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import com.koreait.controller.Manager;
import com.koreait.model.BookInfo;
import com.koreait.model.BookRentalHistoryInfo;
import com.koreait.model.UserInfo;
import com.koreait.view.Tools.messageType;

public class Viewer {

	private JFrame frmMain;
	private JMenuBar mnubMain;
	private JMenu mnuFile;
	private JMenuItem mnuiHome;
	private JMenuItem mnuiEnd;
	private JMenu mnuUserInfoMng;
	private JMenuItem mnuiUserInfoInsert;
	private JMenuItem mnuiUserInfoDelete;
	private JMenuItem mnuiUserInfoUpdate;
	private JMenuItem mnuiUserInfoSelect;
	private JMenu mnuBookInfoMng;
	private JMenuItem mnuiBookInfoInsert;
	private JMenuItem mnuiBookInfoDelete;
	private JMenuItem mnuiBookInfoUpdate;
	private JMenuItem mnuiBookInfoSelect;
	private JMenu mnuBookRentalMng;
	private JMenuItem mnuiBookRentalInsert;
	private JMenuItem mnuiBookReturnInsert;
	private JMenuItem mnuiBookRentalHistorySelect;
	private JMenu mnuHelp;	
	private JLabel lblResultInfo;
	private JPanel pnlMain;
	private JLabel lblMainTitle;
	private JPanel pnlUserInfoInsert;
	private JPanel pnlUserInfoDelete;
	private JPanel pnlUserInfoUpdate;
	private JPanel pnlUserInfoSelect;
	private JPanel pnlBookInfoInsert;
	private JPanel pnlBookInfoDelete;
	private JPanel pnlBookInfoUpdate;
	private JPanel pnlBookInfoSelect;
	private JPanel pnlBookRentalInsert;
	private JPanel pnlBookReturnInsert;
	private JPanel pnlBookRentalHistorySelect;
	private JTextField txfUserInfoInsertID;
	private JTextField txfUserInfoInsertName;
	private JTextField txfUserInfoInsertPhoneNum;
	private JLabel lblUserInfoDeleteID;
	private JTextField txfUserInfoDeleteID;
	private JButton btnUserInfoDelete;
	private JTextField txfUserInfoUpdateID;
	private JTextField txfUserInfoUpdateName;
	private JTextField txfUserInfoUpdatePhoneNum;
	private JTextField txfUserInfoSelectID;
	private JTextField txfUserInfoSelectName;
	private JTextField txfUserInfoSelectPhoneNum;
	private JScrollPane scrpBookInfo;
	private JButton btnBookInfoSelect;
	private JLabel lblUserInfoSelectID_1;
	private JTextField txfBookInfoSelectID;
	private JLabel lblUserInfoSelectName_1;
	private JTextField txfBookInfoSelectTitle;
	private JLabel lblisbn;
	private JTextField txfBookInfoSelectISBN;
	private JTextField txfBookRentalHistorySelectUserName;
	private JTextField txfBookRentalHistorySelectBookTitle;
	private JTextField txfBookRentalHistorySelectFromDate;
	private JTextField txfBookRentalHistorySelectToDate;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Viewer window = new Viewer();
					window.frmMain.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Viewer() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMain = new JFrame();
		frmMain.getContentPane().setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		frmMain.addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				setPanelVisible("pnlMain");
			}
		});
		frmMain.setBounds(100, 100, 650, 420);
		frmMain.setLocationRelativeTo(null);
		frmMain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMain.getContentPane().setLayout(null);
		
		pnlBookRentalHistorySelect = new JPanel();
		pnlBookRentalHistorySelect.setBounds(0, 21, 634, 336);
		frmMain.getContentPane().add(pnlBookRentalHistorySelect);
		pnlBookRentalHistorySelect.setLayout(null);
		
		JLabel lblBookRentalHistorySelectPnlTitle = new JLabel("[도서 대여 이력 조회]");
		lblBookRentalHistorySelectPnlTitle.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		lblBookRentalHistorySelectPnlTitle.setBounds(1, 5, 200, 15);
		pnlBookRentalHistorySelect.add(lblBookRentalHistorySelectPnlTitle);
		
		String[] tblBookRentalInfoColName = {"사용자ID", "사용자성명", "도서ID", "도서제목", "상태", "일자"}; //0. 제목용 배열
		DefaultTableModel tblBookRentalInfoTableModel = new DefaultTableModel(tblBookRentalInfoColName, 0); //1. DefaultTableModel 추가
		
		JTable tblBookRentalInfo = new JTable(tblBookRentalInfoTableModel); //2. JTable 추가
		tblBookRentalInfo.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		tblBookRentalInfo.setBounds(10, 50, 410, 155);
		
		JScrollPane scrpBookRentalHistory = new JScrollPane(tblBookRentalInfo);
		scrpBookRentalHistory.setBounds(10, 58, 612, 242);
		pnlBookRentalHistorySelect.add(scrpBookRentalHistory);
		
		JButton btnBookRentalHistorySelect = new JButton("조회");
		btnBookRentalHistorySelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookRentalHistoryInfo bookRentalHistoryInfo = new BookRentalHistoryInfo(); //조회조건 정보를 담을 객체
				Manager manager = new Manager(); //정보를 직접 처리할 객체
				ResultSet resultSet = null;
				
				bookRentalHistoryInfo.setUserName(txfBookRentalHistorySelectUserName.getText());
				bookRentalHistoryInfo.setBookTitle(txfBookRentalHistorySelectBookTitle.getText());
				bookRentalHistoryInfo.setFromDate(txfBookRentalHistorySelectFromDate.getText());
				bookRentalHistoryInfo.setToDate(txfBookRentalHistorySelectToDate.getText());
				resultSet = manager.selectBookRentalHistory(bookRentalHistoryInfo);
				
				try {
					tblBookRentalInfoTableModel.setNumRows(0);
					while (resultSet.next()) {
						tblBookRentalInfoTableModel.addRow(
														new Object[] {
															resultSet.getString("UserID"), 
															resultSet.getString("UserName"), 
															resultSet.getString("BookID"), 
															resultSet.getString("BookTitle"),
															resultSet.getString("RentalReturnType"), 
															resultSet.getString("RentalReturnDate") 
														}
													);
					}
					
					Tools.setText(lblResultInfo, "조회 완료", 3, messageType.SUCCESS);
				} catch (SQLException e1) {
					e1.printStackTrace();
				} finally {
					if (resultSet != null) {
						try {
							resultSet.close();
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					}
					
					manager.closeDatabaseConnection();
					manager.closeResultSet();
				}
			}
		});
		btnBookRentalHistorySelect.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnBookRentalHistorySelect.setBounds(14, 305, 97, 23);
		pnlBookRentalHistorySelect.add(btnBookRentalHistorySelect);
		
		JLabel lblUserInfoSelectID_1_1 = new JLabel("사용자성명");
		lblUserInfoSelectID_1_1.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoSelectID_1_1.setBounds(13, 33, 70, 15);
		pnlBookRentalHistorySelect.add(lblUserInfoSelectID_1_1);
		
		txfBookRentalHistorySelectUserName = new JTextField();
		txfBookRentalHistorySelectUserName.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfBookRentalHistorySelectUserName.setColumns(10);
		txfBookRentalHistorySelectUserName.setBounds(80, 30, 116, 21);
		pnlBookRentalHistorySelect.add(txfBookRentalHistorySelectUserName);
		
		JLabel lblUserInfoSelectName_1_1 = new JLabel("책제목");
		lblUserInfoSelectName_1_1.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoSelectName_1_1.setBounds(199, 33, 75, 15);
		pnlBookRentalHistorySelect.add(lblUserInfoSelectName_1_1);
		
		txfBookRentalHistorySelectBookTitle = new JTextField();
		txfBookRentalHistorySelectBookTitle.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfBookRentalHistorySelectBookTitle.setColumns(10);
		txfBookRentalHistorySelectBookTitle.setBounds(278, 30, 116, 21);
		pnlBookRentalHistorySelect.add(txfBookRentalHistorySelectBookTitle);
		
		JLabel lblisbn_1 = new JLabel("기간");
		lblisbn_1.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblisbn_1.setBounds(404, 33, 30, 15);
		pnlBookRentalHistorySelect.add(lblisbn_1);
		
		txfBookRentalHistorySelectFromDate = new JTextField();
		txfBookRentalHistorySelectFromDate.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfBookRentalHistorySelectFromDate.setColumns(10);
		txfBookRentalHistorySelectFromDate.setBounds(431, 30, 80, 21);
		pnlBookRentalHistorySelect.add(txfBookRentalHistorySelectFromDate);
		
		JLabel lblisbn_1_1 = new JLabel("~");
		lblisbn_1_1.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblisbn_1_1.setBounds(523, 33, 30, 15);
		pnlBookRentalHistorySelect.add(lblisbn_1_1);
		
		txfBookRentalHistorySelectToDate = new JTextField();
		txfBookRentalHistorySelectToDate.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfBookRentalHistorySelectToDate.setColumns(10);
		txfBookRentalHistorySelectToDate.setBounds(542, 30, 80, 21);
		pnlBookRentalHistorySelect.add(txfBookRentalHistorySelectToDate);
		
		pnlBookInfoSelect = new JPanel();
		pnlBookInfoSelect.setBounds(0, 21, 634, 336);
		frmMain.getContentPane().add(pnlBookInfoSelect);
		pnlBookInfoSelect.setLayout(null);
		
		JLabel lblBookInfoSelectPnlTitle = new JLabel("[도서 정보 조회]");
		lblBookInfoSelectPnlTitle.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		lblBookInfoSelectPnlTitle.setBounds(1, 5, 200, 15);
		pnlBookInfoSelect.add(lblBookInfoSelectPnlTitle);
		
		String[] tblBookInfoColName = {"도서ID", "도서제목", "도서ISBN"}; //0. 제목용 배열
		DefaultTableModel tblBookInfoTableModel = new DefaultTableModel(tblBookInfoColName, 0); //1. DefaultTableModel 추가
		
		JTable tblBookInfo = new JTable(tblBookInfoTableModel); //2. JTable 추가
		tblBookInfo.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		tblBookInfo.setBounds(10, 50, 410, 155);
		
		scrpBookInfo = new JScrollPane(tblBookInfo);
		scrpBookInfo.setBounds(10, 50, 612, 242);
		pnlBookInfoSelect.add(scrpBookInfo);
		
		btnBookInfoSelect = new JButton("조회");
		btnBookInfoSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookInfo bookInfo = new BookInfo(); //조회조건 정보를 담을 객체
				Manager manager = new Manager(); //정보를 직업 처리할 객체
				ResultSet resultSet = null;
				
				bookInfo.setBookID(txfBookInfoSelectID.getText());
				bookInfo.setBookTitle(txfBookInfoSelectTitle.getText());
				bookInfo.setBookISBN(txfBookInfoSelectISBN.getText());
				resultSet = manager.selectBookInfo(bookInfo);
				
				try {
					tblBookInfoTableModel.setNumRows(0);
					while (resultSet.next()) {
						tblBookInfoTableModel.addRow(
														new Object[] {
															resultSet.getString("BookID"), //1. BookID
															resultSet.getString("BookTitle"), //2. BookTitle
															resultSet.getString("BookISBN") //3. BookISBN
														}
													);
					}
					
					Tools.setText(lblResultInfo, "조회 완료", 3, messageType.SUCCESS);
				} catch (SQLException e1) {
					e1.printStackTrace();
				} finally {
					if (resultSet != null) {
						try {
							resultSet.close();
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					}
					
					manager.closeDatabaseConnection();
					manager.closeResultSet();
				}
			}
		});
		btnBookInfoSelect.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnBookInfoSelect.setBounds(13, 303, 97, 23);
		pnlBookInfoSelect.add(btnBookInfoSelect);
		
		lblUserInfoSelectID_1 = new JLabel("ID");
		lblUserInfoSelectID_1.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoSelectID_1.setBounds(12, 31, 57, 15);
		pnlBookInfoSelect.add(lblUserInfoSelectID_1);
		
		txfBookInfoSelectID = new JTextField();
		txfBookInfoSelectID.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfBookInfoSelectID.setColumns(10);
		txfBookInfoSelectID.setBounds(70, 28, 116, 21);
		pnlBookInfoSelect.add(txfBookInfoSelectID);
		
		lblUserInfoSelectName_1 = new JLabel("도서제목");
		lblUserInfoSelectName_1.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoSelectName_1.setBounds(198, 31, 75, 15);
		pnlBookInfoSelect.add(lblUserInfoSelectName_1);
		
		txfBookInfoSelectTitle = new JTextField();
		txfBookInfoSelectTitle.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfBookInfoSelectTitle.setColumns(10);
		txfBookInfoSelectTitle.setBounds(277, 28, 116, 21);
		pnlBookInfoSelect.add(txfBookInfoSelectTitle);
		
		lblisbn = new JLabel("도서ISBN");
		lblisbn.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblisbn.setBounds(403, 31, 90, 15);
		pnlBookInfoSelect.add(lblisbn);
		
		txfBookInfoSelectISBN = new JTextField();
		txfBookInfoSelectISBN.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfBookInfoSelectISBN.setColumns(10);
		txfBookInfoSelectISBN.setBounds(495, 28, 116, 21);
		pnlBookInfoSelect.add(txfBookInfoSelectISBN);
		
		pnlUserInfoSelect = new JPanel();
		pnlUserInfoSelect.setBounds(0, 21, 634, 336);
		frmMain.getContentPane().add(pnlUserInfoSelect);
		pnlUserInfoSelect.setLayout(null);
		
		JLabel lblUserInfoSelectPnlTitle = new JLabel("[사용자 정보 조회]");
		lblUserInfoSelectPnlTitle.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		lblUserInfoSelectPnlTitle.setBounds(1, 5, 200, 15);
		pnlUserInfoSelect.add(lblUserInfoSelectPnlTitle);
		
		
		String[] tblUserInfoColName = {"사용자ID", "사용자성명", "사용자전화번호"}; //0. 제목용 배열
		DefaultTableModel tblUserInfoTableModel = new DefaultTableModel(tblUserInfoColName, 0); //1. DefaultTableModel 추가
		
		JTable tblUserInfo = new JTable(tblUserInfoTableModel); //2. JTable 추가
		tblUserInfo.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		tblUserInfo.setBounds(10, 50, 410, 155);
		
		JScrollPane scrpUserInfo = new JScrollPane(tblUserInfo); //3. JScrollPane 추가
		scrpUserInfo.setBounds(10, 50, 612, 242);
		pnlUserInfoSelect.add(scrpUserInfo);
		
		JButton btnUserInfoSelect = new JButton("조회");
		btnUserInfoSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserInfo userInfo = new UserInfo(); //조회조건 정보를 담을 객체
				Manager manager = new Manager(); //정보를 직업 처리할 객체
				ResultSet resultSet = null;
				
				userInfo.setUserID(txfUserInfoSelectID.getText());
				userInfo.setUserName(txfUserInfoSelectName.getText());
				userInfo.setUserPhoneNum(txfUserInfoSelectPhoneNum.getText());
				resultSet = manager.selectUserInfo(userInfo);
				
				try {
					tblUserInfoTableModel.setNumRows(0);
					while (resultSet.next()) {
						tblUserInfoTableModel.addRow(
														new Object[] {
															resultSet.getString(1), //1. UserID
															resultSet.getString(2), //2. UserName
															resultSet.getString(3) //3. UserPhoneNum
														}
													);
					}
					
					Tools.setText(lblResultInfo, "조회 완료", 3, messageType.SUCCESS);
				} catch (SQLException e1) {
					e1.printStackTrace();
				} finally {
					if (resultSet != null) {
						try {
							resultSet.close();
						} catch (SQLException e1) {
							e1.printStackTrace();
						}
					}
					
					manager.closeDatabaseConnection();
					manager.closeResultSet();
				}
			}
		});
		btnUserInfoSelect.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnUserInfoSelect.setBounds(12, 302, 97, 23);
		pnlUserInfoSelect.add(btnUserInfoSelect);
		
		JLabel lblUserInfoSelectID = new JLabel("ID");
		lblUserInfoSelectID.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoSelectID.setBounds(11, 30, 57, 15);
		pnlUserInfoSelect.add(lblUserInfoSelectID);
		
		txfUserInfoSelectID = new JTextField();
		txfUserInfoSelectID.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfUserInfoSelectID.setBounds(69, 27, 116, 21);
		pnlUserInfoSelect.add(txfUserInfoSelectID);
		txfUserInfoSelectID.setColumns(10);
		
		JLabel lblUserInfoSelectName = new JLabel("사용자성명");
		lblUserInfoSelectName.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoSelectName.setBounds(197, 30, 75, 15);
		pnlUserInfoSelect.add(lblUserInfoSelectName);
		
		txfUserInfoSelectName = new JTextField();
		txfUserInfoSelectName.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfUserInfoSelectName.setBounds(276, 27, 116, 21);
		pnlUserInfoSelect.add(txfUserInfoSelectName);
		txfUserInfoSelectName.setColumns(10);
		
		JLabel lblUserInfoSelectPhoneNum = new JLabel("사용자전화번호");
		lblUserInfoSelectPhoneNum.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoSelectPhoneNum.setBounds(402, 30, 90, 15);
		pnlUserInfoSelect.add(lblUserInfoSelectPhoneNum);
		
		txfUserInfoSelectPhoneNum = new JTextField();
		txfUserInfoSelectPhoneNum.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfUserInfoSelectPhoneNum.setBounds(494, 27, 116, 21);
		pnlUserInfoSelect.add(txfUserInfoSelectPhoneNum);
		txfUserInfoSelectPhoneNum.setColumns(10);
		
		pnlUserInfoUpdate = new JPanel();
		pnlUserInfoUpdate.setBounds(0, 21, 634, 336);
		frmMain.getContentPane().add(pnlUserInfoUpdate);
		pnlUserInfoUpdate.setLayout(null);
		
		JLabel lblUserInfoUpdatePnlTitle = new JLabel("[사용자 정보 수정]");
		lblUserInfoUpdatePnlTitle.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		lblUserInfoUpdatePnlTitle.setBounds(1, 5, 200, 15);
		pnlUserInfoUpdate.add(lblUserInfoUpdatePnlTitle);
		
		JLabel lblUserInfoUpdateID = new JLabel("ID");
		lblUserInfoUpdateID.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoUpdateID.setBounds(94, 52, 57, 15);
		pnlUserInfoUpdate.add(lblUserInfoUpdateID);
		
		JLabel lblUserInfoUpdateName = new JLabel("이름");
		lblUserInfoUpdateName.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoUpdateName.setBounds(94, 77, 57, 15);
		pnlUserInfoUpdate.add(lblUserInfoUpdateName);
		
		JLabel lblUserInfoUpdatePhoneNum = new JLabel("전화번호");
		lblUserInfoUpdatePhoneNum.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoUpdatePhoneNum.setBounds(94, 102, 57, 15);
		pnlUserInfoUpdate.add(lblUserInfoUpdatePhoneNum);
		
		txfUserInfoUpdateID = new JTextField();
		txfUserInfoUpdateID.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfUserInfoUpdateID.setBounds(163, 49, 116, 21);
		pnlUserInfoUpdate.add(txfUserInfoUpdateID);
		txfUserInfoUpdateID.setColumns(10);
		
		txfUserInfoUpdateName = new JTextField();
		txfUserInfoUpdateName.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfUserInfoUpdateName.setBounds(163, 74, 116, 21);
		pnlUserInfoUpdate.add(txfUserInfoUpdateName);
		txfUserInfoUpdateName.setColumns(10);
		
		txfUserInfoUpdatePhoneNum = new JTextField();
		txfUserInfoUpdatePhoneNum.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfUserInfoUpdatePhoneNum.setBounds(163, 99, 116, 21);
		pnlUserInfoUpdate.add(txfUserInfoUpdatePhoneNum);
		txfUserInfoUpdatePhoneNum.setColumns(10);
		
		JButton btnNewButton = new JButton("수정");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserInfo userInfo = new UserInfo(); //정보(사용자)를 저장할 객체(Model영역)
				Manager manager = new Manager(); //정보를 직접 처리(등록,수정,삭제,조회)할 객체(Controller영역)
				
				try {
					userInfo.setUserID(txfUserInfoUpdateID.getText());
					userInfo.setUserName(txfUserInfoUpdateName.getText());
					userInfo.setUserPhoneNum(txfUserInfoUpdatePhoneNum.getText());
					
					if (Tools.openAlert("수정하시겠습니까?") == 0) {
						boolean result = manager.updateUserInfo(userInfo);
						
						if (result == true) {
							Tools.setText(lblResultInfo, "수정 완료", 3, messageType.SUCCESS);
						} else {
							Tools.setText(lblResultInfo, "오류 발생", 3, messageType.ERROR);
						}
					}
				} catch (Exception ex) {
					Tools.setText(lblResultInfo, ex.getMessage(), 3, messageType.ERROR);
				} finally {
					manager.closeDatabaseConnection();
				}
			}
		});
		btnNewButton.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnNewButton.setBounds(104, 146, 97, 23);
		pnlUserInfoUpdate.add(btnNewButton);
		
		pnlUserInfoDelete = new JPanel();
		pnlUserInfoDelete.setBounds(0, 21, 634, 336);
		frmMain.getContentPane().add(pnlUserInfoDelete);
		pnlUserInfoDelete.setLayout(null);
		
		JLabel lblUserInfoDeletePnlTitle = new JLabel("[사용자 정보 삭제]");
		lblUserInfoDeletePnlTitle.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		lblUserInfoDeletePnlTitle.setBounds(1, 5, 200, 15);
		pnlUserInfoDelete.add(lblUserInfoDeletePnlTitle);
		
		lblUserInfoDeleteID = new JLabel("ID");
		lblUserInfoDeleteID.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoDeleteID.setBounds(66, 58, 57, 15);
		pnlUserInfoDelete.add(lblUserInfoDeleteID);
		
		txfUserInfoDeleteID = new JTextField();
		txfUserInfoDeleteID.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfUserInfoDeleteID.setColumns(10);
		txfUserInfoDeleteID.setBounds(150, 55, 116, 21);
		pnlUserInfoDelete.add(txfUserInfoDeleteID);
		
		btnUserInfoDelete = new JButton("삭제");
		btnUserInfoDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//1단계 : MVC 패턴 없이 구현
				//1. DB연결
				//2. DB에 전달할 정보 지정
				//3. 쿼리 생성
				//4. 쿼리 실행

				//2단계 : DAO 객체를 사용(MVC 패턴 미사용)
				
				//3단계 : MVC 패턴 사용
				UserInfo userInfo = new UserInfo();
				Manager manager = new Manager();
				
				try {
					userInfo.setUserID(txfUserInfoDeleteID.getText());
					if (Tools.openAlert("삭제하시겠습니까?") == 0) {
						boolean result = manager.deleteUserInfo(userInfo);
						
						if (result == true) {
							Tools.setText(lblResultInfo, "삭제 완료", 3, Tools.messageType.SUCCESS);
						} else {
							Tools.setText(lblResultInfo, "오류 발생", 3, Tools.messageType.ERROR);
						}
					}
				} catch (Exception ex) {
					Tools.setText(lblResultInfo, ex.getMessage(), 3, Tools.messageType.ERROR);
				} finally {
					manager.closeDatabaseConnection();
				}
			}
		});
		btnUserInfoDelete.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnUserInfoDelete.setBounds(66, 152, 97, 23);
		pnlUserInfoDelete.add(btnUserInfoDelete);
		
		pnlUserInfoInsert = new JPanel();
		pnlUserInfoInsert.setBounds(0, 21, 634, 336);
		frmMain.getContentPane().add(pnlUserInfoInsert);
		pnlUserInfoInsert.setLayout(null);
		
		JLabel lblUserInfoInsertID = new JLabel("ID");
		lblUserInfoInsertID.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoInsertID.setBounds(86, 72, 57, 15);
		pnlUserInfoInsert.add(lblUserInfoInsertID);
		
		JLabel lblUserInfoInsertName = new JLabel("이름");
		lblUserInfoInsertName.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoInsertName.setBounds(86, 97, 57, 15);
		pnlUserInfoInsert.add(lblUserInfoInsertName);
		
		JLabel lblUserInfoInsertPhoneNum = new JLabel("전화번호");
		lblUserInfoInsertPhoneNum.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblUserInfoInsertPhoneNum.setBounds(86, 122, 57, 15);
		pnlUserInfoInsert.add(lblUserInfoInsertPhoneNum);
		
		JLabel lblUserInfoInsertPnlTitle = new JLabel("[사용자 정보 등록]");
		lblUserInfoInsertPnlTitle.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		lblUserInfoInsertPnlTitle.setBounds(1, 5, 200, 15);
		pnlUserInfoInsert.add(lblUserInfoInsertPnlTitle);
		
		txfUserInfoInsertID = new JTextField();
		txfUserInfoInsertID.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfUserInfoInsertID.setBounds(170, 69, 116, 21);
		pnlUserInfoInsert.add(txfUserInfoInsertID);
		txfUserInfoInsertID.setColumns(10);
		
		txfUserInfoInsertName = new JTextField();
		txfUserInfoInsertName.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfUserInfoInsertName.setBounds(170, 94, 116, 21);
		pnlUserInfoInsert.add(txfUserInfoInsertName);
		txfUserInfoInsertName.setColumns(10);
		
		txfUserInfoInsertPhoneNum = new JTextField();
		txfUserInfoInsertPhoneNum.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		txfUserInfoInsertPhoneNum.setBounds(170, 119, 116, 21);
		pnlUserInfoInsert.add(txfUserInfoInsertPhoneNum);
		txfUserInfoInsertPhoneNum.setColumns(10);
		
		JButton btnUserInfoInsert = new JButton("등록");
		btnUserInfoInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//1단계 : MVC 패턴 없이 구현
				//1. DB연결
				//2. DB에 전달할 정보 지정
				//3. 쿼리 생성
				//4. 쿼리 실행
				
//				Connection con = null; //데이터베이스 연결된 상태를 저장하는 객체
//				PreparedStatement prsmt = null; //SQL문을 나타내는 객체
//				String qStr; //SQL문용 String
//				
//				qStr = "INSERT INTO UserInfo (UserID, UserName, UserPhoneNum) VALUES (?, ?, ?)";
//				try {
//					Class.forName("org.sqlite.JDBC");
//					con = DriverManager.getConnection("jdbc:sqlite:./././Resources/Database/BookManagement.db");
//					prsmt = con.prepareStatement(qStr);
//					
////					prsmt.setString(1, "16"); //ID
////					prsmt.setString(2, "사용자16"); //이름
////					prsmt.setString(3, "010-0000-0016"); //전화번호
//					
//					//텍스트필드의 값을 읽어와서
//					prsmt.setString(1, txfUserInfoInsertID.getText()); //ID
//					prsmt.setString(2, txfUserInfoInsertName.getText()); //이름
//					prsmt.setString(3, txfUserInfoInsertPhoneNum.getText()); //전화번호
//					
//					prsmt.executeUpdate();
//					
//					con.close();					
//				} catch (Exception e1) {
//					e1.printStackTrace();
//				}
								
				//2단계 : DAO 객체를 사용(MVC 패턴 미사용)
//				DatabaseAccessHelper dah = new DatabaseAccessHelper();
//				String qStr;
//				
//				qStr = "INSERT INTO UserInfo (UserID, UserName, UserPhoneNum) VALUES (?, ?, ?)";
//				
//				try {
//					ArrayList<DataPack> dataPack = new ArrayList<DataPack>();
//					dataPack.add(new DataPack(1, txfUserInfoInsertID.getText()));
//					dataPack.add(new DataPack(2, txfUserInfoInsertName.getText()));
//					dataPack.add(new DataPack(3, txfUserInfoInsertPhoneNum.getText()));
//					
//					dah.executeUpdate(qStr, dataPack);
//				} catch (Exception ex) {
//					System.out.println(ex.getMessage());
//				}
				
				//3단계 : MVC 패턴 사용
				UserInfo userInfo = new UserInfo(); //정보(사용자)를 저장할 객체(Model영역)
				Manager manager = new Manager(); //정보를 직접 처리(등록,수정,삭제,조회)할 객체(Controler영역)
				
				try {
					userInfo.setUserID(txfUserInfoInsertID.getText());
					userInfo.setUserName(txfUserInfoInsertName.getText());
					userInfo.setUserPhoneNum(txfUserInfoInsertPhoneNum.getText());
					
					boolean result = manager.insertUserInfo(userInfo);
					
					if (result == true) {
						Tools.setText(lblResultInfo, "등록 완료", 3, messageType.SUCCESS);
					} else {
						Tools.setText(lblResultInfo, "오류 발생", 3, messageType.ERROR);
					}
				} catch (Exception ex) {
					Tools.setText(lblResultInfo, ex.getMessage(), 3, messageType.ERROR);
				} finally {
					manager.closeDatabaseConnection();
				}
			}
		});
		btnUserInfoInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		btnUserInfoInsert.setBounds(86, 166, 97, 23);
		pnlUserInfoInsert.add(btnUserInfoInsert);
		
		mnubMain = new JMenuBar();
		mnubMain.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.setBounds(0, 0, 634, 23);
		frmMain.getContentPane().add(mnubMain);
		
		mnuFile = new JMenu("파일");
		mnuFile.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuFile);
		
		mnuiHome = new JMenuItem("홈");
		mnuiHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlMain");
			}
		});
		mnuiHome.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuFile.add(mnuiHome);
		
		mnuiEnd = new JMenuItem("종료");
		mnuiEnd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnuiEnd.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuFile.add(mnuiEnd);
		
		mnuUserInfoMng = new JMenu("사용자 정보 관리");
		mnuUserInfoMng.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuUserInfoMng);
		
		mnuiUserInfoInsert = new JMenuItem("사용자 정보 등록");
		mnuiUserInfoInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlUserInfoInsert");
			}
		});
		mnuiUserInfoInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuUserInfoMng.add(mnuiUserInfoInsert);
		
		mnuiUserInfoDelete = new JMenuItem("사용자 정보 삭제");
		mnuiUserInfoDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlUserInfoDelete");
			}
		});
		mnuiUserInfoDelete.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuUserInfoMng.add(mnuiUserInfoDelete);
		
		mnuiUserInfoUpdate = new JMenuItem("사용자 정보 수정");
		mnuiUserInfoUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlUserInfoUpdate");
			}
		});
		mnuiUserInfoUpdate.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuUserInfoMng.add(mnuiUserInfoUpdate);
		
		mnuiUserInfoSelect = new JMenuItem("사용자 정보 조회");
		mnuiUserInfoSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlUserInfoSelect");
			}
		});
		mnuiUserInfoSelect.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuUserInfoMng.add(mnuiUserInfoSelect);
		
		mnuBookInfoMng = new JMenu("도서 정보 관리");
		mnuBookInfoMng.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuBookInfoMng);
		
		mnuiBookInfoInsert = new JMenuItem("도서 정보 등록");
		mnuiBookInfoInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookInfoInsert");
			}
		});
		mnuiBookInfoInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookInfoMng.add(mnuiBookInfoInsert);
		
		mnuiBookInfoDelete = new JMenuItem("도서 정보 삭제");
		mnuiBookInfoDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookInfoDelete");
			}
		});
		mnuiBookInfoDelete.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookInfoMng.add(mnuiBookInfoDelete);
		
		mnuiBookInfoUpdate = new JMenuItem("도서 정보 수정");
		mnuiBookInfoUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookInfoUpdate");
			}
		});
		mnuiBookInfoUpdate.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookInfoMng.add(mnuiBookInfoUpdate);
		
		mnuiBookInfoSelect = new JMenuItem("도서 정보 조회");
		mnuiBookInfoSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookInfoSelect");
			}
		});
		mnuiBookInfoSelect.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookInfoMng.add(mnuiBookInfoSelect);
		
		mnuBookRentalMng = new JMenu("도서 대여 관리");
		mnuBookRentalMng.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuBookRentalMng);
		
		mnuiBookRentalInsert = new JMenuItem("도서 대출 등록");
		mnuiBookRentalInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookRentalInsert");
			}
		});
		mnuiBookRentalInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookRentalMng.add(mnuiBookRentalInsert);
		
		mnuiBookReturnInsert = new JMenuItem("도서 반납 등록");
		mnuiBookReturnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookReturnInsert");
			}
		});
		mnuiBookReturnInsert.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookRentalMng.add(mnuiBookReturnInsert);
		
		mnuiBookRentalHistorySelect = new JMenuItem("도서 대여 이력 조회");
		mnuiBookRentalHistorySelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setPanelVisible("pnlBookRentalHistorySelect");
			}
		});
		mnuiBookRentalHistorySelect.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnuBookRentalMng.add(mnuiBookRentalHistorySelect);
		
		mnuHelp = new JMenu("도움말");
		mnuHelp.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		mnubMain.add(mnuHelp);
		
		lblResultInfo = new JLabel("");
		lblResultInfo.setFont(new Font("맑은 고딕", Font.PLAIN, 12));
		lblResultInfo.setBounds(0, 366, 634, 15);
		frmMain.getContentPane().add(lblResultInfo);
		
		pnlMain = new JPanel();
		pnlMain.setBounds(0, 21, 634, 336);
		frmMain.getContentPane().add(pnlMain);
		pnlMain.setLayout(null);
		
		lblMainTitle = new JLabel("도서 대여 관리 프로그램");
		lblMainTitle.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		lblMainTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblMainTitle.setBounds(0, 143, 634, 48);
		pnlMain.add(lblMainTitle);
		
		pnlBookInfoInsert = new JPanel();
		pnlBookInfoInsert.setBounds(0, 21, 634, 336);
		frmMain.getContentPane().add(pnlBookInfoInsert);
		pnlBookInfoInsert.setLayout(null);
		
		JLabel lblBookInfoInsertPnlTitle = new JLabel("[도서 정보 등록]");
		lblBookInfoInsertPnlTitle.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		lblBookInfoInsertPnlTitle.setBounds(1, 5, 200, 15);
		pnlBookInfoInsert.add(lblBookInfoInsertPnlTitle);
		
		pnlBookInfoDelete = new JPanel();
		pnlBookInfoDelete.setBounds(0, 21, 634, 336);
		frmMain.getContentPane().add(pnlBookInfoDelete);
		pnlBookInfoDelete.setLayout(null);
		
		JLabel lblBookInfoDeletePnlTitle = new JLabel("[도서 정보 삭제]");
		lblBookInfoDeletePnlTitle.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		lblBookInfoDeletePnlTitle.setBounds(1, 5, 200, 15);
		pnlBookInfoDelete.add(lblBookInfoDeletePnlTitle);
		
		pnlBookInfoUpdate = new JPanel();
		pnlBookInfoUpdate.setBounds(0, 21, 634, 336);
		frmMain.getContentPane().add(pnlBookInfoUpdate);
		pnlBookInfoUpdate.setLayout(null);
		
		JLabel lblBookInfoUpdatePnlTitle = new JLabel("[도서 정보 수정]");
		lblBookInfoUpdatePnlTitle.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		lblBookInfoUpdatePnlTitle.setBounds(1, 5, 200, 15);
		pnlBookInfoUpdate.add(lblBookInfoUpdatePnlTitle);
		
		pnlBookRentalInsert = new JPanel();
		pnlBookRentalInsert.setBounds(0, 21, 634, 336);
		frmMain.getContentPane().add(pnlBookRentalInsert);
		pnlBookRentalInsert.setLayout(null);
		
		JLabel lblBookRentalInsertPnlTitle = new JLabel("[도서 대출 등록]");
		lblBookRentalInsertPnlTitle.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		lblBookRentalInsertPnlTitle.setBounds(1, 5, 200, 15);
		pnlBookRentalInsert.add(lblBookRentalInsertPnlTitle);
		
		pnlBookReturnInsert = new JPanel();
		pnlBookReturnInsert.setBounds(0, 21, 634, 336);
		frmMain.getContentPane().add(pnlBookReturnInsert);
		pnlBookReturnInsert.setLayout(null);
		
		JLabel lblBookReturnInsertPnlTitle = new JLabel("[도서 반납 등록]");
		lblBookReturnInsertPnlTitle.setFont(new Font("맑은 고딕", Font.BOLD, 12));
		lblBookReturnInsertPnlTitle.setBounds(1, 5, 200, 15);
		pnlBookReturnInsert.add(lblBookReturnInsertPnlTitle);
	}
	
	/*
	 * 리플렉션(객체를 통해 클래스의 정보를 알아냄)을 이용하여 Panel Visible 설정 
	 */
	private void setPanelVisible(String panelName) {
		try {
			Class<?> c = Class.forName("com.koreait.view.Viewer");
			Field[] allField = c.getDeclaredFields();
			
			for (Field field : allField){
				if (field.getType().getName().equals("javax.swing.JPanel")) { //panel 일 때
					//field.setAccessible(true); //private 멤버에 접근 가능하게 설정
					
					JPanel p = (JPanel)field.get(this); //JPanel로 형변환
					
					if (field.getName().equals(panelName)) {
						p.setVisible(true);
					} else {
						p.setVisible(false);
					}
				}
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
