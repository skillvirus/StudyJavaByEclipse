package com.koreait.model;

public class BookInfo {

}
