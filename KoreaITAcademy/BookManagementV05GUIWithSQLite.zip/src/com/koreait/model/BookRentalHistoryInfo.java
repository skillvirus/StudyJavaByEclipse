package com.koreait.model;

public class BookRentalHistoryInfo {

}
