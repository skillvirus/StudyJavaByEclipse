package com.koreait.model;

public class BookRentalHistoryInfo {
	private String userID; //고객ID
	private String userName; //고객성명
	private String bookID; //도서ID
	private String bookTitle; //도서제목
	private String rentalReturnType; //대출,반납 타입
	private String rentalReturnDate; //대출,반납 일자
	
	public String getUserID() {
		return userID;
	}
	
	public void setUserID(String userID) {
		this.userID = userID;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getBookID() {
		return bookID;
	}
	
	public void setBookID(String bookID) {
		this.bookID = bookID;
	}
	
	public String getBookTitle() {
		return bookTitle;
	}
	
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	
	public String getRentalReturnType() {
		return rentalReturnType;
	}
	
	public void setRentalReturnType(String rentalReturnType) {
		this.rentalReturnType = rentalReturnType;
	}
	
	public String getRentalReturnDate() {
		return rentalReturnDate;
	}
	
	public void setRentalReturnDate(String rentalReturnDate) {
		this.rentalReturnDate = rentalReturnDate;
	}
}
