package com.koreait.model;

public class UserInfo {

}
