package com.koreait.controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.koreait.model.BookInfo;
import com.koreait.model.BookRentalHistoryInfo;
import com.koreait.model.UserInfo;

public class Manager {
	
	//클래스 객체명 = new 클래스();
	DatabaseAccessHelper databaseAccessHelper = null;
	ArrayList<DataPack> dataPack = null;
	ResultSet resultSet = null;
	String queryString = null;
	
	public Manager() {
		databaseAccessHelper = new DatabaseAccessHelper();
		dataPack = new ArrayList<DataPack>();
	}
	
	/*
	 * 사용자 정보 등록
	 */
	public boolean insertUserInfo(UserInfo userInfo) {
		boolean returnValue = false;
		
		return returnValue;
	}
	
	
	/*
	 * 사용자 정보 삭제
	 */
	public boolean deleteUserInfo(UserInfo userInfo) {
		boolean returnValue = false;
		
		return returnValue;
	}
	
	/*
	 * 사용자 정보 수정
	 */
	public boolean updateUserInfo(UserInfo userInfo) {
		boolean returnValue = false;
		
		return returnValue;
	}
	
	/*
	 * 사용자 정보 조회
	 */
	public ResultSet selectUserInfo(UserInfo userInfo) {
		
		return resultSet;
	}
	
	/*
	 * 도서 정보 등록
	 */
	public boolean insertBookInfo(BookInfo bookInfo) {
		boolean returnValue = false;
		
		return returnValue;
	}
	
	/*
	 * 도서 정보 삭제
	 */
	public boolean deleteBookInfo(BookInfo bookInfo) {
		boolean returnValue = false;
		
		return returnValue;
	}
	
	/*
	 * 도서 정보 수정
	 */
	public boolean updateBookInfo(BookInfo bookInfo) {
		boolean returnValue = false;
		
		return returnValue;
	}
	
	/*
	 * 도서 정보 조회
	 */
	public ResultSet selectBookInfo(BookInfo bookInfo) {
		
		return resultSet;
	}
	
	/*
	 * 도서 대출 등록
	 */
	public boolean insertBookRental(BookRentalHistoryInfo bookRentalHistoryInfo) {
		boolean returnValue = false;
		
		return returnValue;
	}
	
	/*
	 * 도서 반납 등록
	 */
	public boolean insertBookReturn(BookRentalHistoryInfo bookRentalHisotryInfo) {
		boolean returnValue = false;
		
		return returnValue;
	}
	
	/*
	 * 도서 대여 이력 조회
	 */
	public ResultSet selectBookRentalHistory(BookRentalHistoryInfo bookRentalHistoryInfo) {
		
		return resultSet;
	}
	
	/*
	 * 데이터베이스 접속 해제
	 */
	public void closeDatabaseConnection() {
		if (databaseAccessHelper != null) {
			databaseAccessHelper.close();
		}
	}	
	
	/*
	 * ResultSet 해제
	 */
	public void closeResultSet() {
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}



















