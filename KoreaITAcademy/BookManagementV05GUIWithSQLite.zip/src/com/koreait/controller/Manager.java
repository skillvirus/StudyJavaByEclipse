package com.koreait.controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.koreait.model.BookInfo;
import com.koreait.model.BookRentalHistoryInfo;
import com.koreait.model.UserInfo;

public class Manager {
	
	//클래스 객체명 = new 클래스();
	DatabaseAccessHelper databaseAccessHelper = null;
	ArrayList<DataPack> dataPack = null;
	ResultSet resultSet = null;
	String queryString = null;
	
	public Manager() {
		databaseAccessHelper = new DatabaseAccessHelper();
		dataPack = new ArrayList<DataPack>();
	}
	
	/*
	 * 사용자 정보 등록
	 */
	public boolean insertUserInfo(UserInfo userInfo) {
		boolean returnValue = false;
		
		//queryString = "INSERT INTO UserInfo (UserID, UserName, UserPhoneNum) VALUES (?, ?, ?)";
		
		try {
		
			queryString = "INSERT INTO UserInfo "
						+ "("
						+ "		UserID, " //고객ID
						+ "		UserName, " //고객이름
						+ "		UserPhoneNum" //고객전화번호
						+ ") "
						+ "VALUES "
						+ "("
						+ "		?, "
						+ "		?, "
						+ "		?"
						+ ")";
			
			dataPack.add(new DataPack(1, userInfo.getUserID()));
			dataPack.add(new DataPack(2, userInfo.getUserName()));
			dataPack.add(new DataPack(3, userInfo.getUserPhoneNum()));
			databaseAccessHelper.executeUpdate(queryString, dataPack);
			
			returnValue = true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		return returnValue;
	}
	
	
	/*
	 * 사용자 정보 삭제
	 */
	public boolean deleteUserInfo(UserInfo userInfo) {
		boolean returnValue = false;
		
		try {
			queryString = "DELETE"
					   + " FROM 	UserInfo"
					   + " WHERE 	UserID = ?";
			
			dataPack.add(new DataPack(1, userInfo.getUserID()));
			
			databaseAccessHelper.executeUpdate(queryString, dataPack);
			
			returnValue = true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		return returnValue;
	}
	
	/*
	 * 사용자 정보 수정
	 */
	public boolean updateUserInfo(UserInfo userInfo) {
		boolean returnValue = false;
		
		try {
			
			queryString = "UPDATE UserInfo"
					   + " SET	  UserName = ?,"
					   + "        UserPhoneNum = ?"
					   + " WHERE  UserID = ?";
						
			dataPack.add(new DataPack(1, userInfo.getUserName()));
			dataPack.add(new DataPack(2, userInfo.getUserPhoneNum()));
			dataPack.add(new DataPack(3, userInfo.getUserID()));
			databaseAccessHelper.executeUpdate(queryString, dataPack);
			
			returnValue = true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		return returnValue;
	}
	
	/*
	 * 사용자 정보 조회
	 */
	public ResultSet selectUserInfo(UserInfo userInfo) {
		try {
			queryString = "SELECT 	UserID, "
					   + "          UserName, "
					   + "          UserPhoneNum "
					   + " FROM 	UserInfo "
					   + " WHERE 	UserID = CASE WHEN ? = '' THEN UserID ELSE ? END"
					   + " 			AND UserName LIKE ?"
					   + " 			AND UserPhoneNum LIKE ?";
			
			dataPack = new ArrayList<DataPack>();
			dataPack.add(new DataPack(1, userInfo.getUserID()));
			dataPack.add(new DataPack(2, userInfo.getUserID()));
			dataPack.add(new DataPack(3, "%" + userInfo.getUserName() + "%"));
			dataPack.add(new DataPack(4, "%" + userInfo.getUserPhoneNum() + "%"));
			
			resultSet = databaseAccessHelper.executeQuery(queryString, dataPack);
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		return resultSet;
	}
	
	/*
	 * 도서 정보 등록
	 */
	public boolean insertBookInfo(BookInfo bookInfo) {
		boolean returnValue = false;
		
		try {
			
			queryString = "INSERT INTO BookInfo "
						+ "("
						+ "		BookID, " //도서ID
						+ "		BookTitle, " //도서 제목
						+ "		BookISBN" //도서ISBN
						+ ") "
						+ "VALUES "
						+ "("
						+ "		?, "
						+ "		?, "
						+ "		?"
						+ ")";
			
			dataPack.add(new DataPack(1, bookInfo.getBookID()));
			dataPack.add(new DataPack(2, bookInfo.getBookTitle()));
			dataPack.add(new DataPack(3, bookInfo.getBookISBN()));
			databaseAccessHelper.executeUpdate(queryString, dataPack);
			
			returnValue = true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		return returnValue;
	}
	
	/*
	 * 도서 정보 삭제
	 */
	public boolean deleteBookInfo(BookInfo bookInfo) {
		boolean returnValue = false;
		
		try {
			queryString = "DELETE"
					   + " FROM 	BookInfo"
					   + " WHERE 	BookID = ?";
			
			dataPack.add(new DataPack(1, bookInfo.getBookID()));
			
			databaseAccessHelper.executeUpdate(queryString, dataPack);
			
			returnValue = true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		return returnValue;
	}
	
	/*
	 * 도서 정보 수정
	 */
	public boolean updateBookInfo(BookInfo bookInfo) {
		boolean returnValue = false;
		
		try {
			
			queryString = "UPDATE BookInfo"
					   + " SET	  BookTitle = ?,"
					   + "        BookISBN = ?"
					   + " WHERE  BookID = ?";
						
			dataPack.add(new DataPack(1, bookInfo.getBookTitle()));
			dataPack.add(new DataPack(2, bookInfo.getBookISBN()));
			dataPack.add(new DataPack(3, bookInfo.getBookID()));
			databaseAccessHelper.executeUpdate(queryString, dataPack);
			
			returnValue = true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		return returnValue;
	}
	
	/*
	 * 도서 정보 조회
	 */
	public ResultSet selectBookInfo(BookInfo bookInfo) {
		
		try {
			queryString = "SELECT 	BookID, "
					   + "          BookTitle, "
					   + "          BookISBN "
					   + " FROM 	BookInfo "
					   + " WHERE 	BookID = CASE WHEN ? = '' THEN BookID ELSE ? END"
					   + " 			AND BookTitle LIKE ?"
					   + " 			AND BookISBN LIKE ?";
			
			dataPack = new ArrayList<DataPack>();
			dataPack.add(new DataPack(1, bookInfo.getBookID()));
			dataPack.add(new DataPack(2, bookInfo.getBookID()));
			dataPack.add(new DataPack(3, "%" + bookInfo.getBookTitle() + "%"));
			dataPack.add(new DataPack(4, "%" + bookInfo.getBookISBN() + "%"));
			
			resultSet = databaseAccessHelper.executeQuery(queryString, dataPack);
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		return resultSet;
	}
	
	/*
	 * 도서 대출 등록
	 */
	public boolean insertBookRental(BookRentalHistoryInfo bookRentalHistoryInfo) {
		boolean returnValue = false;
		
		try {
			
			queryString = "INSERT INTO BookRentalHistoryInfo "
						+ "("
						+ "		UserID, " //사용자ID
						+ "		UserName, " //사용자성명
						+ "		BookID, " //도서ID
						+ "     BookTitle, " //도서제목
						+ "     RentalReturnType," //대출/반납
						+ "     RentalReturnDate" //일자
						+ ") "
						+ "VALUES "
						+ "("
						+ "		?, "
						+ "		?, "
						+ "		?, "
						+ "     ?, "
						+ "     ?, "
						+ "     ?"
						+ ")";
			
			dataPack.add(new DataPack(1, bookRentalHistoryInfo.getUserID()));
			dataPack.add(new DataPack(2, bookRentalHistoryInfo.getUserName()));
			dataPack.add(new DataPack(3, bookRentalHistoryInfo.getBookID()));
			dataPack.add(new DataPack(4, bookRentalHistoryInfo.getBookTitle()));
			dataPack.add(new DataPack(5, "RENTAL"));
			dataPack.add(new DataPack(6, bookRentalHistoryInfo.getRentalReturnDate()));
			databaseAccessHelper.executeUpdate(queryString, dataPack);
			
			returnValue = true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		return returnValue;
	}
	
	/*
	 * 도서 반납 등록
	 */
	public boolean insertBookReturn(BookRentalHistoryInfo bookRentalHistoryInfo) {
		boolean returnValue = false;
		
		try {
			
			queryString = "INSERT INTO BookRentalHistoryInfo "
						+ "("
						+ "		UserID, " //사용자ID
						+ "		UserName, " //사용자성명
						+ "		BookID, " //도서ID
						+ "     BookTitle, " //도서제목
						+ "     RentalReturnType," //대출/반납
						+ "     RentalReturnDate" //일자
						+ ") "
						+ "VALUES "
						+ "("
						+ "		?, "
						+ "		?, "
						+ "		?, "
						+ "     ?, "
						+ "     ?, "
						+ "     ?"
						+ ")";
			
			dataPack.add(new DataPack(1, bookRentalHistoryInfo.getUserID()));
			dataPack.add(new DataPack(2, bookRentalHistoryInfo.getUserName()));
			dataPack.add(new DataPack(3, bookRentalHistoryInfo.getBookID()));
			dataPack.add(new DataPack(4, bookRentalHistoryInfo.getBookTitle()));
			dataPack.add(new DataPack(5, "RETURN"));
			dataPack.add(new DataPack(6, bookRentalHistoryInfo.getRentalReturnDate()));
			databaseAccessHelper.executeUpdate(queryString, dataPack);
			
			returnValue = true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		return returnValue;
	}
	
	/*
	 * 도서 대여 이력 조회
	 */
	public ResultSet selectBookRentalHistory(BookRentalHistoryInfo bookRentalHistoryInfo) {
		try {
			queryString = "SELECT 	UserID, "
					   + "          UserName, "
					   + "          BookID, "
					   + "          BookTitle, "
					   + "          RentalReturnType, "
					   + "          RentalReturnDate"
					   + " FROM 	BookRentalHistoryInfo "
					   + " WHERE 	UserName LIKE ?"
					   + " 			AND BookTitle LIKE ?"
					   + " 			AND RentalReturnDate >= CASE WHEN ? = '' THEN RentalReturnDate ELSE ? END"
					   + "          AND RentalReturnDate <= CASE WHEN ? = '' THEN RentalReturnDate ELSE ? END";
			
			dataPack = new ArrayList<DataPack>();
			dataPack.add(new DataPack(1, "%" + bookRentalHistoryInfo.getUserName() + "%"));
			dataPack.add(new DataPack(2, "%" + bookRentalHistoryInfo.getBookTitle() + "%"));
			dataPack.add(new DataPack(3, bookRentalHistoryInfo.getFromDate()));
			dataPack.add(new DataPack(4, bookRentalHistoryInfo.getFromDate()));
			dataPack.add(new DataPack(5, bookRentalHistoryInfo.getToDate()));
			dataPack.add(new DataPack(6, bookRentalHistoryInfo.getToDate()));
			
			resultSet = databaseAccessHelper.executeQuery(queryString, dataPack);
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		return resultSet;
	}
	
	/*
	 * 데이터베이스 접속 해제
	 */
	public void closeDatabaseConnection() {
		if (databaseAccessHelper != null) {
			databaseAccessHelper.close();
		}
	}	
	
	/*
	 * ResultSet 해제
	 */
	public void closeResultSet() {
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}



















