package com.koreait.controller;

public class DataPack {
	private Object code; //코드
	private Object value; //값
	private Object type; //형태
	
	//생성자1
	public DataPack(Object code, Object value) {
		this.code = code;
		this.value = value;
	}
	
	//생성자2
	public DataPack(Object code, Object value, Object type) {
		this.code = code;
		this.value = value;
		this.type = type;
	}

	public Object getCode() {
		return code;
	}

	public void setCode(Object code) {
		this.code = code;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public Object getType() {
		return type;
	}

	public void setType(Object type) {
		this.type = type;
	}
}











